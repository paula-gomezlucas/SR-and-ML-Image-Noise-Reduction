.. only:: html

    Bibliography
    ============

.. bibliography:: references.bib
    :style: adsarxiv

